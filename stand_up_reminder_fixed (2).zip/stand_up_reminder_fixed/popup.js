// Stand Up Reminder - Popup con Contador Regresivo
class StandUpReminderPopup {
    constructor() {
        this.elements = {
            statusIndicator: document.getElementById('statusIndicator'),
            statusText: document.getElementById('statusText'),
            timeRemaining: document.getElementById('timeRemaining'),
            timeLabel: document.getElementById('timeLabel'),
            progressFill: document.getElementById('progressFill'),
            nextAlarm: document.getElementById('nextAlarm'),
            healthTip: document.getElementById('healthTip'),
            tipText: document.getElementById('tipText')
        };
        
        this.updateInterval = null;
        this.healthTips = [
            "Mantén una buena postura mientras trabajas",
            "Haz estiramientos suaves cada hora",
            "Respira profundamente y relaja los hombros",
            "Mueve los ojos para descansar la vista",
            "Hidrátate regularmente durante el día",
            "Camina un poco durante los descansos",
            "Estira los brazos y las piernas",
            "Haz rotaciones suaves del cuello"
        ];
        
        this.init();
    }

    async init() {
        // Verificar si es un día nuevo antes de actualizar el estado
        await this.checkDayReset();
        this.updateStatus();
        this.startUpdateTimer();
        this.updateHealthTip();
    }

    // Verificar reset de día
    async checkDayReset() {
        try {
            await chrome.runtime.sendMessage({ type: "checkDayReset" });
        } catch (error) {
            console.log("Verificación de día nuevo completada");
        }
    }

    // Obtener el estado actual de las alarmas
    async getCurrentStatus() {
        try {
            const alarms = await chrome.alarms.getAll();
            const workAlarm = alarms.find(a => a.name === "workTimer");
            const breakAlarm = alarms.find(a => a.name === "breakTimer");
            
            return {
                isOnBreak: !!breakAlarm,
                workAlarm: workAlarm,
                breakAlarm: breakAlarm,
                currentTime: Date.now()
            };
        } catch (error) {
            console.error('Error al obtener estado:', error);
            return { isOnBreak: false, currentTime: Date.now() };
        }
    }

    // Calcular tiempo restante
    calculateTimeRemaining(alarm) {
        if (!alarm || !alarm.scheduledTime) return { minutes: 0, seconds: 0, percentage: 0 };
        
        const now = Date.now();
        const scheduled = alarm.scheduledTime;
        const remaining = Math.max(0, scheduled - now);
        
        const minutes = Math.floor(remaining / 60000);
        const seconds = Math.floor((remaining % 60000) / 1000);
        const total = alarm.name === "workTimer" ? 60 : 5; // 60 min trabajo, 5 min descanso
        const elapsed = total - (remaining / 60000);
        const percentage = Math.min(100, Math.max(0, (elapsed / total) * 100));
        
        return { minutes, seconds, percentage };
    }

    // Formatear tiempo
    formatTime(minutes, seconds) {
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }

    // Actualizar el estado visual
    async updateStatus() {
        try {
            const status = await this.getCurrentStatus();
            const isOnBreak = status.isOnBreak;
            
            // Actualizar indicador de estado
            this.elements.statusIndicator.className = `status-indicator ${isOnBreak ? 'break' : 'working'}`;
            
            // Actualizar texto de estado
            if (isOnBreak) {
                this.elements.statusText.textContent = "En descanso - ¡Estirándose!";
            } else {
                this.elements.statusText.textContent = "Trabajando - Sentado";
            }
            
            // Calcular tiempo restante
            let timeInfo;
            if (isOnBreak && status.breakAlarm) {
                timeInfo = this.calculateTimeRemaining(status.breakAlarm);
                this.elements.timeLabel.textContent = `Te quedan ${timeInfo.minutes} min ${timeInfo.seconds} seg parado`;
            } else if (status.workAlarm) {
                timeInfo = this.calculateTimeRemaining(status.workAlarm);
                this.elements.timeLabel.textContent = `Te quedan ${timeInfo.minutes} min ${timeInfo.seconds} seg sentado`;
            } else {
                timeInfo = { minutes: 0, seconds: 0, percentage: 0 };
                this.elements.timeLabel.textContent = "Calculando tiempo...";
            }
            
            // Actualizar contador
            this.elements.timeRemaining.textContent = this.formatTime(timeInfo.minutes, timeInfo.seconds);
            
            // Actualizar barra de progreso
            this.elements.progressFill.style.width = `${timeInfo.percentage}%`;
            this.elements.progressFill.className = `progress-fill ${isOnBreak ? 'break' : ''}`;
            
            // Actualizar próxima alarma
            this.updateNextAlarm(status);
            
        } catch (error) {
            console.error('Error al actualizar estado:', error);
            this.elements.statusText.textContent = "Error al obtener estado";
            this.elements.timeLabel.textContent = "Revisa la consola";
        }
    }

    // Actualizar información de próxima alarma
    updateNextAlarm(status) {
        try {
            if (status.isOnBreak && status.breakAlarm) {
                const breakEnd = new Date(status.breakAlarm.scheduledTime);
                const nextWork = new Date(breakEnd.getTime() + 60000); // +1 minuto
                this.elements.nextAlarm.innerHTML = `<strong>Próxima alarma:</strong> ${nextWork.toLocaleTimeString()} - Volver al trabajo`;
            } else if (status.workAlarm) {
                const workEnd = new Date(status.workAlarm.scheduledTime);
                this.elements.nextAlarm.innerHTML = `<strong>Próxima alarma:</strong> ${workEnd.toLocaleTimeString()} - Hora de estirarse`;
            } else {
                this.elements.nextAlarm.innerHTML = `<strong>Próxima alarma:</strong> Calculando...`;
            }
        } catch (error) {
            this.elements.nextAlarm.innerHTML = `<strong>Próxima alarma:</strong> Error al calcular`;
        }
    }

    // Actualizar consejo de salud
    updateHealthTip() {
        const randomTip = this.healthTips[Math.floor(Math.random() * this.healthTips.length)];
        this.elements.tipText.textContent = randomTip;
    }

    // Iniciar timer de actualización
    startUpdateTimer() {
        // Actualizar cada segundo para el contador regresivo
        this.updateInterval = setInterval(() => {
            this.updateStatus();
        }, 1000);
    }

    // Limpiar recursos
    destroy() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
        }
    }
}

// Inicializar cuando se carga el popup
document.addEventListener('DOMContentLoaded', () => {
    const popup = new StandUpReminderPopup();
    
    // Limpiar al cerrar el popup
    window.addEventListener('beforeunload', () => {
        popup.destroy();
    });
});

// Manejar errores de Chrome API
window.addEventListener('error', (event) => {
    console.error('Error en popup:', event.error);
    document.getElementById('statusText').textContent = "Error en la extensión";
    document.getElementById('timeLabel').textContent = "Revisa la consola para más detalles";
});
