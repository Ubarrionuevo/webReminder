// Unit Testing para Stand Up Reminder
// Este archivo simula y prueba la funcionalidad de los temporizadores

class StandUpReminderTester {
  constructor() {
    this.workIntervalMinutes = 60;
    this.breakIntervalMinutes = 5;
    this.isOnBreak = false;
    this.testMode = true;
    this.logs = [];
    this.workStartTime = null;
  }

  // Función para calcular el próximo horario "redondo" (cada hora en punto)
  getNextHourlyTime() {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    
    // Calcular cuántos minutos faltan para la próxima hora en punto
    const minutesUntilNextHour = 60 - currentMinute;
    
    // Si estamos en el minuto 0, la próxima hora es en 60 minutos
    const delayMinutes = minutesUntilNextHour === 0 ? 60 : minutesUntilNextHour;
    
    const nextHourTime = new Date(now.getTime() + delayMinutes * 60 * 1000);
    
    return {
      delayMinutes: delayMinutes,
      nextHourTime: nextHourTime
    };
  }

  // Simular la creación de alarmas
  createAlarm(name, delayInMinutes, periodInMinutes = null) {
    const alarm = {
      name: name,
      delayInMinutes: delayInMinutes,
      periodInMinutes: periodInMinutes,
      scheduledTime: new Date(Date.now() + delayInMinutes * 60 * 1000)
    };
    
    this.log(`Alarma creada: ${name} - Delay: ${delayInMinutes} min - Programada para: ${alarm.scheduledTime.toLocaleTimeString()}`);
    return alarm;
  }

  // Simular el timer de trabajo
  startWorkTimer() {
    // Si es la primera vez, calcular el horario óptimo
    if (!this.workStartTime) {
      this.workStartTime = new Date();
      const timeInfo = this.getNextHourlyTime();
      const initialDelay = timeInfo.delayMinutes;
      
      this.log(`🚀 Iniciando timer de trabajo - Primera alarma: ${initialDelay} minutos hasta la próxima hora en punto`);
      this.log(`⏰ Próximo horario en punto: ${timeInfo.nextHourTime.toLocaleTimeString()}`);
      
      // Simular que la primera alarma se dispara después del tiempo calculado
      setTimeout(() => {
        this.handleWorkTimerComplete();
      }, initialDelay * 60 * 1000);
      
      return this.createAlarm("workTimer", initialDelay);
    } else {
      // Para alarmas recurrentes, usar el intervalo estándar
      this.log(`🚀 Timer de trabajo recurrente: ${this.workIntervalMinutes} minutos`);
      const workAlarm = this.createAlarm("workTimer", this.workIntervalMinutes, this.workIntervalMinutes);
      
      // Simular que la alarma se dispara después del tiempo especificado
      setTimeout(() => {
        this.handleWorkTimerComplete();
      }, this.workIntervalMinutes * 60 * 1000);
      
      return workAlarm;
    }
  }

  // Simular el timer de descanso
  startBreakTimer() {
    this.log("⏸️ Iniciando timer de descanso (5 minutos)");
    const breakAlarm = this.createAlarm("breakTimer", this.breakIntervalMinutes);
    
    // Simular que la alarma se dispara después del tiempo especificado
    setTimeout(() => {
      this.handleBreakTimerComplete();
    }, this.breakIntervalMinutes * 60 * 1000);
    
    return breakAlarm;
  }

  // Manejar cuando termina el timer de trabajo
  handleWorkTimerComplete() {
    this.log("🔔 ¡ALARMA DE TRABAJO! - Hora de estirarse");
    this.notifyUser("¡Hora de estirarse!", "Has estado una hora sentado. Tomate 5 minutos para moverte.");
    this.isOnBreak = true;
    this.startBreakTimer();
  }

  // Manejar cuando termina el timer de descanso
  handleBreakTimerComplete() {
    this.log("🔔 ¡ALARMA DE DESCANSO! - Volver al trabajo");
    this.notifyUser("¡Volvé al trabajo!", "Ya pasaron los 5 minutos de descanso. Podés seguir.");
    this.isOnBreak = false;
    this.startWorkTimer(); // Reiniciar el ciclo
  }

  // Simular notificaciones
  notifyUser(title, message) {
    this.log(`📢 NOTIFICACIÓN: ${title} - ${message}`);
    console.log(`%c${title}`, 'color: red; font-size: 16px; font-weight: bold;');
    console.log(`%c${message}`, 'color: blue; font-size: 14px;');
  }

  // Función de logging
  log(message) {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = `[${timestamp}] ${message}`;
    this.logs.push(logEntry);
    console.log(logEntry);
  }

  // Test rápido con intervalos reducidos para verificación
  runQuickTest() {
    this.log("🧪 INICIANDO TEST RÁPIDO (intervalos reducidos para testing)");
    this.workIntervalMinutes = 0.1; // 6 segundos
    this.breakIntervalMinutes = 0.05; // 3 segundos
    
    this.log("⏱️ Test configurado:");
    this.log(`   - Trabajo: ${this.workIntervalMinutes} minutos (${this.workIntervalMinutes * 60} segundos)`);
    this.log(`   - Descanso: ${this.breakIntervalMinutes} minutos (${this.breakIntervalMinutes * 60} segundos)`);
    
    this.startWorkTimer();
    
    // Mostrar logs en tiempo real
    this.startLogging();
  }

  // Test con intervalos reales
  runRealTest() {
    this.log("🎯 INICIANDO TEST CON INTERVALOS REALES");
    this.workIntervalMinutes = 60; // 1 hora real
    this.breakIntervalMinutes = 5; // 5 minutos reales
    
    this.log("⏱️ Test configurado:");
    this.log(`   - Trabajo: ${this.workIntervalMinutes} minutos (1 hora)`);
    this.log(`   - Descanso: ${this.breakIntervalMinutes} minutos`);
    
    this.startWorkTimer();
    this.startLogging();
  }

  // Test de adaptación al horario actual
  runTimeAdaptationTest() {
    this.log("⏰ INICIANDO TEST DE ADAPTACIÓN AL HORARIO");
    this.workIntervalMinutes = 60; // 1 hora real
    this.breakIntervalMinutes = 5; // 5 minutos reales
    
    this.log("⏱️ Test configurado:");
    this.log(`   - Trabajo: ${this.workIntervalMinutes} minutos (1 hora)`);
    this.log(`   - Descanso: ${this.breakIntervalMinutes} minutos`);
    this.log("🕐 Se calculará automáticamente el próximo horario en punto");
    
    this.startWorkTimer();
    this.startLogging();
  }

  // Mostrar logs en tiempo real
  startLogging() {
    setInterval(() => {
      const now = new Date();
      const status = this.isOnBreak ? "DESCANSO" : "TRABAJO";
      console.log(`%c[${now.toLocaleTimeString()}] Estado actual: ${status}`, 'color: green;');
    }, 10000); // Log cada 10 segundos
  }

  // Mostrar todos los logs
  showLogs() {
    console.log("📋 HISTORIAL COMPLETO DE LOGS:");
    this.logs.forEach(log => console.log(log));
  }

  // Verificar estado actual
  getCurrentStatus() {
    return {
      isOnBreak: this.isOnBreak,
      workInterval: this.workIntervalMinutes,
      breakInterval: this.breakIntervalMinutes,
      totalLogs: this.logs.length
    };
  }
}

// Función para ejecutar tests desde la consola del navegador
function runTests() {
  console.log("🧪 STAND UP REMINDER - UNIT TESTING");
  console.log("=====================================");
  
  const tester = new StandUpReminderTester();
  
  // Agregar al objeto global para acceso desde consola
  window.standUpTester = tester;
  
  console.log("Comandos disponibles:");
  console.log("- tester.runQuickTest() - Test rápido (6s trabajo, 3s descanso)");
  console.log("- tester.runRealTest() - Test real (1h trabajo, 5min descanso)");
  console.log("- tester.showLogs() - Mostrar historial de logs");
  console.log("- tester.getCurrentStatus() - Estado actual");
  
  return tester;
}

// Auto-ejecutar cuando se carga el script
if (typeof window !== 'undefined') {
  window.runStandUpTests = runTests;
  console.log("✅ Testing framework cargado. Ejecuta 'runStandUpTests()' para comenzar.");
}
