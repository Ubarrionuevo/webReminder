# 🕐 Ejemplos de Adaptación Horaria - Stand Up Reminder

## 📋 Cómo Funciona la Adaptación

La extensión ahora se adapta inteligentemente al horario en que se instala, calculando automáticamente cuándo debe sonar la primera alarma para sincronizarse con las horas "en punto".

## 🎯 Ejemplos Prácticos

### **Ejemplo 1: Instalación a las 13:35**
```
⏰ Horario actual: 13:35
⏰ Próximo horario en punto: 14:00
⏰ Minutos hasta la próxima hora: 25
🚀 Primera alarma programada para: 14:00
⏱️ Segunda alarma: 15:00 (1 hora después)
⏱️ Tercera alarma: 16:00 (1 hora después)
```

### **Ejemplo 2: Instalación a las 14:00**
```
⏰ Horario actual: 14:00
⏰ Próximo horario en punto: 15:00
⏰ Minutos hasta la próxima hora: 60
🚀 Primera alarma programada para: 15:00
⏱️ Segunda alarma: 16:00 (1 hora después)
⏱️ Tercera alarma: 17:00 (1 hora después)
```

### **Ejemplo 3: Instalación a las 15:45**
```
⏰ Horario actual: 15:45
⏰ Próximo horario en punto: 16:00
⏰ Minutos hasta la próxima hora: 15
🚀 Primera alarma programada para: 16:00
⏱️ Segunda alarma: 17:00 (1 hora después)
⏱️ Tercera alarma: 18:00 (1 hora después)
```

### **Ejemplo 4: Instalación a las 23:30**
```
⏰ Horario actual: 23:30
⏰ Próximo horario en punto: 00:00 (día siguiente)
⏰ Minutos hasta la próxima hora: 30
🚀 Primera alarma programada para: 00:00
⏱️ Segunda alarma: 01:00 (1 hora después)
⏱️ Tercera alarma: 02:00 (1 hora después)
```

## 🔄 Ciclo Completo de Funcionamiento

### **Fase 1: Instalación y Cálculo**
1. Usuario instala la extensión
2. Sistema detecta el horario actual
3. Calcula minutos hasta la próxima hora en punto
4. Programa la primera alarma

### **Fase 2: Primera Alarma**
1. Suena la alarma en el horario calculado
2. Usuario recibe notificación: "¡Hora de estirarse!"
3. Se inicia el timer de descanso (5 minutos)

### **Fase 3: Descanso**
1. Timer de descanso cuenta 5 minutos
2. Suena alarma de fin de descanso
3. Usuario recibe notificación: "¡Volvé al trabajo!"

### **Fase 4: Ciclo Recurrente**
1. Se reinicia el timer de trabajo (60 minutos exactos)
2. El ciclo se repite cada hora en punto
3. Sistema mantiene sincronización con horarios redondos

## 💡 Ventajas de la Adaptación Horaria

### ✅ **Para el Usuario:**
- **Horarios predecibles**: Siempre sabe cuándo será la próxima alarma
- **Sincronización natural**: Se adapta a su horario de trabajo
- **No interrupciones aleatorias**: Las alarmas suenan en momentos lógicos

### ✅ **Para el Sistema:**
- **Eficiencia**: No desperdicia tiempo esperando
- **Consistencia**: Mantiene horarios regulares
- **Escalabilidad**: Funciona igual sin importar cuándo se instale

## 🧪 Cómo Probar la Adaptación

### **1. Test Visual (test.html)**
- Haz clic en "⏰ Test Adaptación Horario"
- Observa cómo calcula el próximo horario en punto
- Verifica que la primera alarma se sincronice correctamente

### **2. Test de la Extensión Real**
- Instala la extensión en diferentes horarios
- Verifica que las alarmas suenen en horas en punto
- Monitorea los logs para confirmar el cálculo

### **3. Verificación de Logs**
```
[13:35] Stand Up Reminder: 🚀 Extensión instalada - Calculando horario óptimo
[13:35] Stand Up Reminder: ⏰ Horario actual: 13:35
[13:35] Stand Up Reminder: ⏰ Próximo horario en punto: 14:00
[13:35] Stand Up Reminder: ⏰ Minutos hasta la próxima hora: 25
[13:35] Stand Up Reminder: ⏱️ Primera alarma de trabajo: 25 minutos hasta la próxima hora en punto
[13:35] Stand Up Reminder: ✅ Primera alarma programada para: 14:00
```

## 🔧 Configuración Avanzada

Si quieres personalizar aún más el comportamiento, puedes modificar estas constantes en `background.js`:

```javascript
// Cambiar el intervalo de trabajo (en minutos)
const WORK_INTERVAL_MINUTES = 60;

// Cambiar el intervalo de descanso (en minutos)
const BREAK_INTERVAL_MINUTES = 5;

// Para testing rápido, puedes usar valores menores:
// const WORK_INTERVAL_MINUTES = 1;    // 1 minuto
// const BREAK_INTERVAL_MINUTES = 0.5; // 30 segundos
```

## 📱 Casos de Uso Reales

### **Oficina 9:00 - 18:00**
- Instalación a las 8:45 → Primera alarma a las 9:00
- Alarmas regulares: 10:00, 11:00, 12:00, 13:00, 14:00, 15:00, 16:00, 17:00

### **Trabajo desde Casa**
- Instalación a las 10:23 → Primera alarma a las 11:00
- Alarmas regulares: 12:00, 13:00, 14:00, 15:00, 16:00

### **Turno Nocturno**
- Instalación a las 22:47 → Primera alarma a las 23:00
- Alarmas regulares: 00:00, 01:00, 02:00, 03:00, 04:00

## 🎯 Resumen

La extensión ahora es **inteligente y adaptable**:
- ✅ Se sincroniza automáticamente con tu horario
- ✅ Calcula el momento óptimo para la primera alarma
- ✅ Mantiene horarios regulares y predecibles
- ✅ Se adapta a cualquier momento del día
- ✅ Funciona perfectamente para turnos de trabajo

¡Ya no más alarmas a horarios extraños! 🎉


