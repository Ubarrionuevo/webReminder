# 🧪 Stand Up Reminder - Guía de Testing

## 📋 Descripción del Proyecto

Esta extensión de Chrome funciona como un recordatorio para que los usuarios se paren y estiren cada hora mientras trabajan frente a la computadora. El ciclo funciona de la siguiente manera:

- **Trabajo**: 60 minutos continuos
- **Descanso**: 5 minutos de pausa
- **Ciclo**: Se repite indefinidamente
- **Adaptación Horaria**: Se sincroniza automáticamente con el horario actual

### 🕐 Sistema de Adaptación Horaria

La extensión ahora se adapta inteligentemente al horario en que se instala:

- **Ejemplo 1**: Si instalas a las 13:35, la primera alarma será a las 14:00 (25 minutos después)
- **Ejemplo 2**: Si instalas a las 14:00, la primera alarma será a las 15:00 (60 minutos después)
- **Ejemplo 3**: Si instalas a las 15:45, la primera alarma será a las 16:00 (15 minutos después)

Después de la primera alarma, el sistema mantiene el ciclo estándar de 1 hora en punto.

## 🚀 Cómo Probar la Extensión

### Opción 1: Testing Visual (Recomendado)

1. **Abrir el archivo de testing**:
   ```
   Abre test.html en tu navegador
   ```

2. **Ejecutar test rápido** (para verificar la lógica):
   - Haz clic en "🧪 Test Rápido (6s/3s)"
   - Esto simula 6 segundos de trabajo y 3 segundos de descanso
   - Perfecto para verificar que la lógica funciona correctamente

3. **Ejecutar test real** (para probar intervalos reales):
   - Haz clic en "🎯 Test Real (1h/5min)"
   - Esto usa los intervalos reales: 1 hora de trabajo, 5 minutos de descanso

4. **Monitorear en tiempo real**:
   - Los logs se muestran en la interfaz web
   - También puedes abrir la consola del navegador (F12) para ver logs detallados

### Opción 2: Testing de la Extensión Real

1. **Cargar la extensión en Chrome**:
   - Abre Chrome y ve a `chrome://extensions/`
   - Activa "Modo desarrollador"
   - Haz clic en "Cargar descomprimida"
   - Selecciona la carpeta del proyecto

2. **Verificar la instalación**:
   - La extensión debería aparecer en la barra de herramientas
   - Haz clic en el ícono para ver el popup
   - Debería mostrar "Ciclo actual: trabajando..."

3. **Monitorear logs**:
   - Abre las herramientas de desarrollador (F12)
   - Ve a la pestaña "Console"
   - Los logs de la extensión aparecerán ahí

4. **Probar notificaciones**:
   - Espera 1 hora para ver la primera notificación
   - O modifica temporalmente `WORK_INTERVAL_MINUTES` en `background.js` a un valor menor (ej: 1 minuto)

## 📊 Qué Verificar

### ✅ Funcionalidades Básicas

- [ ] **Instalación**: La extensión se instala correctamente
- [ ] **Timer de trabajo**: Se inicia automáticamente al instalar
- [ ] **Notificaciones**: Aparecen las notificaciones de Chrome
- [ ] **Ciclo de descanso**: Después de 1 hora, inicia el descanso de 5 minutos
- [ ] **Ciclo continuo**: Después del descanso, vuelve al trabajo
- [ ] **Popup**: Muestra el estado correcto (trabajando/descanso)

### ✅ Logs y Debugging

- [ ] **Logs de instalación**: "🚀 Extensión instalada - Iniciando timer de trabajo"
- [ ] **Logs de alarmas**: "⏱️ Creando alarma de trabajo: 60 minutos"
- [ ] **Logs de notificaciones**: "📢 Enviando notificación: ¡Hora de estirarse!"
- [ ] **Logs de ciclo**: "💼 Fin del período de trabajo" y "⏸️ Fin del período de descanso"

### ✅ Comportamiento Esperado

1. **Al instalar**: Se crea una alarma de trabajo de 60 minutos
2. **Después de 1 hora**: Se dispara la alarma, muestra notificación de descanso
3. **Se inicia descanso**: Se crea una alarma de descanso de 5 minutos
4. **Después de 5 minutos**: Se dispara la alarma, muestra notificación de volver al trabajo
5. **Se reinicia ciclo**: Vuelve al paso 1

## 🔧 Troubleshooting

### Problema: No aparecen notificaciones
**Solución**: 
- Verifica que las notificaciones estén habilitadas en Chrome
- Ve a Configuración > Privacidad y seguridad > Notificaciones del sitio
- Asegúrate de que Chrome tenga permisos de notificación

### Problema: Los timers no funcionan
**Solución**:
- Verifica que la extensión esté habilitada
- Revisa la consola del navegador para errores
- Intenta recargar la extensión

### Problema: No se reinicia el ciclo
**Solución**:
- Verifica que `startWorkTimer()` se llame después del descanso
- Revisa los logs en la consola

## 📝 Archivos de Testing

- `test.js`: Framework de testing con simulación de timers
- `test.html`: Interfaz visual para testing
- `background.js`: Código principal con logs mejorados
- `README_TESTING.md`: Esta guía

## 🎯 Comandos Útiles para Consola

```javascript
// Ver todas las alarmas activas
chrome.alarms.getAll((alarms) => console.log(alarms));

// Ver estado de la extensión
chrome.runtime.getBackgroundPage((page) => console.log(page));

// Limpiar todas las alarmas
chrome.alarms.clearAll();
```

## ⚡ Test Rápido para Desarrollo

Para desarrollo, puedes modificar temporalmente estos valores en `background.js`:

```javascript
const WORK_INTERVAL_MINUTES = 1;  // 1 minuto en lugar de 60
const BREAK_INTERVAL_MINUTES = 0.5;  // 30 segundos en lugar de 5
```

Esto te permitirá probar el ciclo completo en 1.5 minutos en lugar de 65 minutos.
