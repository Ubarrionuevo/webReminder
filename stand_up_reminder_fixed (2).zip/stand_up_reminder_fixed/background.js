const WORK_INTERVAL_MINUTES = 60;
const BREAK_INTERVAL_MINUTES = 5;

let isOnBreak = false;
let workStartTime = null;
let lastKnownDate = null;

// Función de logging para debugging
function log(message) {
  const timestamp = new Date().toLocaleTimeString();
  console.log(`[${timestamp}] Stand Up Reminder: ${message}`);
}

// Función para verificar si es un día nuevo
async function isNewDay() {
  const now = new Date();
  const currentDate = now.toDateString(); // "Mon Dec 25 2023"
  
  try {
    // Obtener la fecha guardada del storage
    const result = await chrome.storage.local.get(['lastKnownDate']);
    const storedDate = result.lastKnownDate;
    
    if (storedDate === undefined) {
      // Primera vez que se ejecuta
      await chrome.storage.local.set({ lastKnownDate: currentDate });
      log(`📅 Primer día detectado: ${currentDate}`);
      return false;
    }
    
    if (storedDate !== currentDate) {
      log(`📅 ¡Día nuevo detectado! Anterior: ${storedDate}, Actual: ${currentDate}`);
      await chrome.storage.local.set({ lastKnownDate: currentDate });
      return true;
    }
    
    return false;
  } catch (error) {
    log(`❌ Error al verificar fecha: ${error.message}`);
    return false;
  }
}

// Función para reiniciar el sistema en un día nuevo
function resetForNewDay() {
  log("🔄 Reiniciando sistema para nuevo día");
  
  // Limpiar todas las alarmas existentes
  chrome.alarms.clearAll(() => {
    log("🗑️ Alarmas anteriores limpiadas");
    
    // Reiniciar variables
    isOnBreak = false;
    workStartTime = new Date();
    
    // Iniciar nuevo ciclo
    startWorkTimer();
  });
}

// Función para calcular el próximo horario "redondo" (cada hora en punto)
function getNextHourlyTime() {
  const now = new Date();
  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();
  
  // Calcular cuántos minutos faltan para la próxima hora en punto
  const minutesUntilNextHour = 60 - currentMinute;
  
  // Si estamos en el minuto 0, la próxima hora es en 60 minutos
  const delayMinutes = minutesUntilNextHour === 0 ? 60 : minutesUntilNextHour;
  
  const nextHourTime = new Date(now.getTime() + delayMinutes * 60 * 1000);
  
  log(`⏰ Horario actual: ${now.toLocaleTimeString()}`);
  log(`⏰ Próximo horario en punto: ${nextHourTime.toLocaleTimeString()}`);
  log(`⏰ Minutos hasta la próxima hora: ${delayMinutes}`);
  
  return {
    delayMinutes: delayMinutes,
    nextHourTime: nextHourTime
  };
}

// Función para verificar y manejar el estado al iniciar
async function initializeOrReset() {
  try {
    const newDayDetected = await isNewDay();
    
    if (newDayDetected) {
      log("🌅 Día nuevo detectado - Reiniciando ciclo");
      resetForNewDay();
    } else {
      log("📅 Mismo día - Continuando ciclo actual");
      // Verificar si hay alarmas activas, si no las hay, iniciar
      chrome.alarms.getAll((alarms) => {
        if (alarms.length === 0) {
          log("⏰ No hay alarmas activas - Iniciando nuevo ciclo");
          workStartTime = new Date();
          startWorkTimer();
        } else {
          log(`⏰ ${alarms.length} alarmas activas encontradas - Continuando`);
        }
      });
    }
  } catch (error) {
    log(`❌ Error en inicialización: ${error.message}`);
    // En caso de error, iniciar normalmente
    workStartTime = new Date();
    startWorkTimer();
  }
}

chrome.runtime.onInstalled.addListener(() => {
  log("🚀 Extensión instalada - Inicializando sistema");
  initializeOrReset();
});

// Escuchar cuando el navegador se inicia
chrome.runtime.onStartup.addListener(() => {
  log("🌅 Navegador iniciado - Verificando estado");
  initializeOrReset();
});

// Escuchar cuando se activa la extensión (cuando se abre una pestaña)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "checkDayReset") {
    log("🔍 Verificando reset de día desde popup");
    initializeOrReset().then(() => {
      sendResponse({ success: true });
    });
    return true; // Mantener el mensaje activo para respuesta asíncrona
  }
});

// Verificar estado cada vez que se activa la extensión
chrome.runtime.onInstalled.addListener(() => {
  log("🚀 Extensión instalada - Inicializando sistema");
  initializeOrReset();
});

// También verificar cuando se actualiza la extensión
chrome.runtime.onUpdateAvailable.addListener(() => {
  log("🔄 Actualización disponible - Verificando estado");
  initializeOrReset();
});

function startWorkTimer() {
  // Si es la primera vez, calcular el horario óptimo
  if (!workStartTime || isOnBreak === false) {
    const timeInfo = getNextHourlyTime();
    const initialDelay = timeInfo.delayMinutes;
    
    log(`⏱️ Primera alarma de trabajo: ${initialDelay} minutos hasta la próxima hora en punto`);
    
    chrome.alarms.create("workTimer", {
      delayInMinutes: initialDelay
    });
    
    // Verificar que la alarma se creó correctamente
    chrome.alarms.get("workTimer", (alarm) => {
      if (alarm) {
        const scheduledTime = new Date(alarm.scheduledTime);
        log(`✅ Primera alarma programada para: ${scheduledTime.toLocaleTimeString()}`);
      } else {
        log("❌ Error: No se pudo crear la primera alarma de trabajo");
      }
    });
  } else {
    // Para alarmas recurrentes, usar el intervalo estándar
    log(`⏱️ Creando alarma recurrente de trabajo: ${WORK_INTERVAL_MINUTES} minutos`);
    chrome.alarms.create("workTimer", {
      delayInMinutes: WORK_INTERVAL_MINUTES,
      periodInMinutes: WORK_INTERVAL_MINUTES
    });
    
    // Verificar que la alarma se creó correctamente
    chrome.alarms.get("workTimer", (alarm) => {
      if (alarm) {
        const scheduledTime = new Date(alarm.scheduledTime);
        log(`✅ Alarma recurrente programada para: ${scheduledTime.toLocaleTimeString()}`);
      } else {
        log("❌ Error: No se pudo crear la alarma recurrente de trabajo");
      }
    });
  }
}

function startBreakTimer() {
  log(`⏸️ Creando alarma de descanso: ${BREAK_INTERVAL_MINUTES} minutos`);
  chrome.alarms.create("breakTimer", {
    delayInMinutes: BREAK_INTERVAL_MINUTES
  });
  
  // Verificar que la alarma se creó correctamente
  chrome.alarms.get("breakTimer", (alarm) => {
    if (alarm) {
      const scheduledTime = new Date(alarm.scheduledTime);
      log(`✅ Alarma de descanso programada para: ${scheduledTime.toLocaleTimeString()}`);
    } else {
      log("❌ Error: No se pudo crear la alarma de descanso");
    }
  });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  log(`🔔 Alarma disparada: ${alarm.name}`);
  
  if (alarm.name === "workTimer") {
    const workDuration = workStartTime ? Math.round((new Date() - workStartTime) / 60000) : WORK_INTERVAL_MINUTES;
    log(`💼 Fin del período de trabajo (${workDuration} minutos transcurridos)`);
    
    notifyUser("¡Hora de estirarse!", "Has estado una hora sentado. Tomate 5 minutos para moverte.");
    isOnBreak = true;
    startBreakTimer();
    
    // Notificar al popup que el estado cambió
    chrome.runtime.sendMessage({ type: "stateChanged", state: "break" });
  }

  if (alarm.name === "breakTimer") {
    log("⏸️ Fin del período de descanso");
    notifyUser("¡Volvé al trabajo!", "Ya pasaron los 5 minutos de descanso. Podés seguir.");
    isOnBreak = false;
    workStartTime = new Date(); // Reiniciar el timer de trabajo
    startWorkTimer(); // Reiniciar el ciclo de trabajo
    
    // Notificar al popup que el estado cambió
    chrome.runtime.sendMessage({ type: "stateChanged", state: "work" });
  }
});

function notifyUser(title, message) {
  log(`📢 Enviando notificación: ${title} - ${message}`);
  chrome.notifications.create({
    type: "basic",
    iconUrl: "icon128.png",
    title: title,
    message: message,
    priority: 2
  }, (notificationId) => {
    if (chrome.runtime.lastError) {
      log(`❌ Error al crear notificación: ${chrome.runtime.lastError.message}`);
    } else {
      log(`✅ Notificación creada con ID: ${notificationId}`);
    }
  });
}
